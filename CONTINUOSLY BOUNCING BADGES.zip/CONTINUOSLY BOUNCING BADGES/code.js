var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["b1a8a1f1-5393-4c3a-9899-dd58155bcc16","2c16b7e0-ae13-49fb-91df-4cbe5a04b43a","e5b99db4-c723-4d25-ac4b-a8f3de09bb4e","cd36dbcd-c83f-40ea-b852-75af4f41ff1d"],"propsByKey":{"b1a8a1f1-5393-4c3a-9899-dd58155bcc16":{"name":"alienGreen_badge_1","frameCount":2,"frameSize":{"x":49,"y":49},"looping":true,"frameDelay":2,"jsonLastModified":"2020-01-29 19:48:04 UTC","pngLastModified":"2020-01-29 19:48:04 UTC","version":"oJA_StLAuFjArBvI70IttdAWhnlMl8Wo","sourceUrl":"assets/api/v1/animation-library/gamelab/oJA_StLAuFjArBvI70IttdAWhnlMl8Wo/category_characters/alienGreen_badge.png","sourceSize":{"x":98,"y":49},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/oJA_StLAuFjArBvI70IttdAWhnlMl8Wo/category_characters/alienGreen_badge.png"},"2c16b7e0-ae13-49fb-91df-4cbe5a04b43a":{"name":"alienPink_badge_1","frameCount":2,"frameSize":{"x":49,"y":49},"looping":true,"frameDelay":2,"jsonLastModified":"2020-01-29 19:48:05 UTC","pngLastModified":"2020-01-29 19:48:05 UTC","version":"mkU_9f.5u8XgZ1sSNegtcX63W0Fa74Zd","sourceUrl":"assets/api/v1/animation-library/gamelab/mkU_9f.5u8XgZ1sSNegtcX63W0Fa74Zd/category_characters/alienPink_badge.png","sourceSize":{"x":98,"y":49},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/mkU_9f.5u8XgZ1sSNegtcX63W0Fa74Zd/category_characters/alienPink_badge.png"},"e5b99db4-c723-4d25-ac4b-a8f3de09bb4e":{"name":"alienBlue_badge_1","frameCount":2,"frameSize":{"x":49,"y":49},"looping":true,"frameDelay":2,"jsonLastModified":"2020-01-29 19:48:04 UTC","pngLastModified":"2020-01-29 19:48:04 UTC","version":"2I28lytcqm1t.Vh_Xhie3F93hbLO6wER","sourceUrl":"assets/api/v1/animation-library/gamelab/2I28lytcqm1t.Vh_Xhie3F93hbLO6wER/category_characters/alienBlue_badge.png","sourceSize":{"x":98,"y":49},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/2I28lytcqm1t.Vh_Xhie3F93hbLO6wER/category_characters/alienBlue_badge.png"},"cd36dbcd-c83f-40ea-b852-75af4f41ff1d":{"name":"alienBeige_badge_1","frameCount":2,"frameSize":{"x":49,"y":49},"looping":true,"frameDelay":2,"jsonLastModified":"2020-01-29 19:48:03 UTC","pngLastModified":"2020-01-29 19:48:03 UTC","version":"w1sZautXAomvGEP4kA4iBLaUJNnzFNl4","sourceUrl":"assets/api/v1/animation-library/gamelab/w1sZautXAomvGEP4kA4iBLaUJNnzFNl4/category_characters/alienBeige_badge.png","sourceSize":{"x":98,"y":49},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/w1sZautXAomvGEP4kA4iBLaUJNnzFNl4/category_characters/alienBeige_badge.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var ball=createSprite(70,365,20,20);
ball.setAnimation("alienGreen_badge_1");

var person=createSprite(150,365,20,20);
person.setAnimation("alienBlue_badge_1");

var jumpingicecream=createSprite(230,365,20,20);
jumpingicecream.setAnimation("alienPink_badge_1");

var basketball =createSprite(310,365,20,20);
basketball.setAnimation("alienBeige_badge_1");


function draw() {
  background("black");
 
 if (keyDown("space")) {
   ball.velocityY=-10;
  } 
  
  if (keyDown("s")){
    person.velocityY=-10;
  }
  
  if (keyDown("a")){
    jumpingicecream.velocityY=-10;
  }
   
  if(keyDown("w")){
    basketball.velocityY=-10;
  }
  
createEdgeSprites();
ball.bounceOff(topEdge);
ball.bounceOff(bottomEdge);     
person.bounceOff(topEdge); 
person.bounceOff(bottomEdge);      
jumpingicecream.bounceOff(topEdge);
jumpingicecream.bounceOff(bottomEdge);  
basketball.bounceOff(topEdge);
basketball.bounceOff(bottomEdge); 
  
text("press S,A,W,space",150,200);  

 drawSprites(); 
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
